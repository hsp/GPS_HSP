'''
Created on Oct 26, 2011

@author: hansskov-petersen
'''
from GPS_Config import *

def goSlopeSpeedStat(shapeFile, gpsTrack, paramDict, header=False):
    print "Working on", shapeFile, len(gpsTrack.pointLists[0]), "points in a total of", len(gpsTrack.pointLists), "routes"
    for subTrack in range(len(gpsTrack.pointLists)):
        if subTrack > 0:
            if header:
                slopeSpeedOutFileHdl = open(slopeSpeedOutFileName, "w")
                gpsTrack.getSpeedSlope(shapeFile, subTrack, slopeSpeedOutFileHdl, paramDict, True)
            else:
                slopeSpeedOutFileHdl = open(slopeSpeedOutFileName, "a")
                gpsTrack.getSpeedSlope(shapeFile, subTrack, slopeSpeedOutFileHdl, paramDict, False)
            header = False
    print "Done. Slope/Speed parameters written to", slopeSpeedOutFileHdl

    slopeSpeedOutFileHdl.close()
    pass