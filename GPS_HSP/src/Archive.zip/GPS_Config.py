##from xml.dom import minidom

## Raster information
rasterPath = "/Users/hansskov-petersen/Dropbox/Projects/MOVE/HSP_Data"
demFile  = rasterPath + "/dem.txt"
slopeFile = rasterPath + "/slope.txt"
visibilityFile = rasterPath + "/viewshed5000m.txt"
landcoverFile = rasterPath + "/landCover.txt"

## GPS point information
trackPath = "/Users/hansskov-petersen/Dropbox/Projects/MOVE/shp_20111006"
shapeTrack = trackPath + "/trip_000157_20090803.shp"
##shapeTrack = trackPath + "/trip_000199_20090803.shp"
##shapeTrack = trackPath + "/HSP1.shp"

pointTimeDateAttributeName = "zeittxt"
pointIdAttributeName = "datenid"
minNumbPointsInSubRoute = 50

## Boinding box
minX = 800000
maxX = 850000
minY = 158000
maxY = 181000

## CE: Analytical parameters
angle = 180
distance = 0
numbSamplePoints = 4
ceStartFileName = "RP_MAFREINA"
ceAddToFileName = "ver1"
ceOutFilePath = "/Users/hansskov-petersen/Dropbox/Projects/MOVE/results/JBJ"
ceOutFileName =  ceOutFilePath + "/" + ceStartFileName + "_Dist" + str(int(distance)) + "mAng" + str(int(angle)) + "dg_" + ceAddToFileName + ".txt"

## CE: Trip Stat
tsStartFileName = "TripStat_MAFREINA"
tsAddToFileName = "all2"
tsOutFilePath = "/Users/hansskov-petersen/Dropbox/Projects/MOVE/results/JBJ"
tsOutFileName =  tsOutFilePath + "/" + tsStartFileName + "_" + tsAddToFileName + ".txt"

## Slope Speed assessment
slopeSpeedResolution = 100
minSlope = -50
maxSlope =  50
minFlat  = -5
maxFlat  = 5
minSpeed = 2
maxSpeed = 30
slopeSpeedStartFileName = "SlopeSpeed_MAFREINA"
slopeSpeedAddToFileName = "all2"
slopeSpeedOutFilePath = "/Users/hansskov-petersen/Dropbox/Projects/MOVE/results/JBJ"
slopeSpeedOutFileName =  slopeSpeedOutFilePath + "/" + slopeSpeedStartFileName + "_" + str(slopeSpeedResolution) + "m_" + slopeSpeedAddToFileName + ".txt"


## General
delim = ","
noDataValue = -8888
writeNoData = False
countNoData = 0

